/*
 * IconSwap - Nintendo Switch homebrew NRO
 * Assign custom icons to games for use with sys-icon
 * by eradicatinglove
 *
 * FTP server added: press X on game list to open FTP menu.
 * Upload images to sdmc:/icon-manager/ via FTP, then browse
 * and assign them from the file browser.
 */

#include <switch.h>
#include <switch/nacp.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>

// Network / FTP
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>

extern "C" {
#include "stb_image.h"
#include "stb_image_resize2.h"
#include "stb_image_write.h"
}

#define MAX_TITLES      512
#define MAX_FILES       512
#define WINDOW_SIZE     36
#define ICON256_SIZE    256
#define ICON174_SIZE    174
#define ICON256_MAXB    102400
#define ICON174_MAXB    65536
#define JPEG_QUALITY    90
#define MAX_PATH        512

// FTP settings
#define FTP_PORT        5000
#define FTP_UPLOAD_DIR  "sdmc:"
#define FTP_BUF_SIZE    4096
#define FTP_MAX_CLIENTS 4

typedef enum {
    SCREEN_GAMELIST,
    SCREEN_FILEBROWSER,
    SCREEN_CONFIRM,
    SCREEN_RESULT,
    SCREEN_REBOOT_CONFIRM,
    SCREEN_FTP
} Screen;

typedef struct {
    char name[256];
    char fullPath[MAX_PATH];
    int  isDir;
} FileEntry;

// FTP client state
typedef struct {
    int  ctrlFd;
    int  dataFd;
    int  passiveListenFd;
    char cwd[MAX_PATH];
    char recvBuf[FTP_BUF_SIZE];
    int  recvLen;
    char renamePending[MAX_PATH];
    bool loggedIn;
    bool binaryMode;
} FtpClient;

// Globals
static NsApplicationRecord  g_records[MAX_TITLES];
static char                 g_names[MAX_TITLES][0x201];
static s32                  g_recordCount = 0;
static FileEntry            g_files[MAX_FILES];
static int                  g_fileCount   = 0;
static Screen g_screen       = SCREEN_GAMELIST;
static int    g_gameSelected = 0;
static int    g_gameScroll   = 0;
static int    g_fileSelected = 0;
static int    g_fileScroll   = 0;
static char   g_currentDir[MAX_PATH]  = "sdmc:/";
static char   g_selectedImg[MAX_PATH] = "";
static char   g_resultMsg[256]        = "";
static int    g_resultOk = 0;

// FTP state
static int       g_ftpListenFd  = -1;
static FtpClient g_ftpClients[FTP_MAX_CLIENTS];
static char      g_ftpIpStr[32] = "0.0.0.0";
static int       g_ftpEnabled   = 0;
static char      g_ftpStatus[128] = "FTP not started";
static int       g_ftpFilesReceived = 0;

// UTF-8 safe copy: never cuts a multi-byte sequence mid-character
static void utf8_strncpy(char* dst, const char* src, size_t maxBytes) {
    if (!maxBytes) return;
    size_t i = 0, last_safe = 0;
    while (src[i] && i < maxBytes - 1) {
        if ((src[i] & 0xC0) != 0x80) last_safe = i;
        i++;
    }
    if (src[i] && (src[i] & 0xC0) == 0x80) i = last_safe;
    memcpy(dst, src, i);
    dst[i] = '\0';
}

// Image processing
static void jpegWriteCallback(void* ctx, void* data, int size) {
    fwrite(data, 1, size, (FILE*)ctx);
}

static int resizeAndSave(const char* srcPath, const char* dstPath, int targetSize, int maxBytes) {
    int srcW, srcH, channels;
    unsigned char* srcPixels = stbi_load(srcPath, &srcW, &srcH, &channels, 3);
    if (!srcPixels) return 0;

    int cropSize = (srcW < srcH) ? srcW : srcH;
    int cropX = (srcW - cropSize) / 2;
    int cropY = (srcH - cropSize) / 2;

    unsigned char* cropPixels = (unsigned char*)malloc(cropSize * cropSize * 3);
    if (!cropPixels) { stbi_image_free(srcPixels); return 0; }

    for (int row = 0; row < cropSize; row++) {
        memcpy(
            cropPixels + row * cropSize * 3,
            srcPixels + ((cropY + row) * srcW + cropX) * 3,
            cropSize * 3
        );
    }
    stbi_image_free(srcPixels);

    unsigned char* dstPixels = (unsigned char*)malloc(targetSize * targetSize * 3);
    if (!dstPixels) { free(cropPixels); return 0; }
    stbir_resize_uint8_linear(cropPixels, cropSize, cropSize, 0, dstPixels, targetSize, targetSize, 0, STBIR_RGB);
    free(cropPixels);
    FILE* f = fopen(dstPath, "wb");
    if (!f) { free(dstPixels); return 0; }
    int result = stbi_write_jpg_to_func(jpegWriteCallback, f, targetSize, targetSize, 3, dstPixels, JPEG_QUALITY);
    fclose(f);
    struct stat st;
    if (result && stat(dstPath, &st) == 0 && st.st_size > maxBytes) {
        remove(dstPath);
        srcPixels = stbi_load(srcPath, &srcW, &srcH, &channels, 3);
        if (!srcPixels) { free(dstPixels); return 0; }
        cropSize = (srcW < srcH) ? srcW : srcH;
        cropX = (srcW - cropSize) / 2;
        cropY = (srcH - cropSize) / 2;
        cropPixels = (unsigned char*)malloc(cropSize * cropSize * 3);
        if (!cropPixels) { stbi_image_free(srcPixels); free(dstPixels); return 0; }
        for (int row = 0; row < cropSize; row++) {
            memcpy(cropPixels + row * cropSize * 3,
                   srcPixels + ((cropY + row) * srcW + cropX) * 3,
                   cropSize * 3);
        }
        stbi_image_free(srcPixels);
        stbir_resize_uint8_linear(cropPixels, cropSize, cropSize, 0, dstPixels, targetSize, targetSize, 0, STBIR_RGB);
        free(cropPixels);
        f = fopen(dstPath, "wb");
        if (!f) { free(dstPixels); return 0; }
        result = stbi_write_jpg_to_func(jpegWriteCallback, f, targetSize, targetSize, 3, dstPixels, 75);
        fclose(f);
    }
    free(dstPixels);
    return result;
}

static void applyIcon(const char* srcPath, u64 titleId) {
    char dst256[MAX_PATH], dst174[MAX_PATH];
    char folder[MAX_PATH];
    snprintf(folder, sizeof(folder), "sdmc:/atmosphere/contents/%016lx", titleId);
    mkdir(folder, 0777);
    snprintf(dst256, sizeof(dst256), "sdmc:/atmosphere/contents/%016lx/icon.jpg",    titleId);
    snprintf(dst174, sizeof(dst174), "sdmc:/atmosphere/contents/%016lx/icon174.jpg", titleId);
    int ok256 = resizeAndSave(srcPath, dst256, ICON256_SIZE, ICON256_MAXB);
    int ok174 = resizeAndSave(srcPath, dst174, ICON174_SIZE, ICON174_MAXB);
    if (ok256 && ok174) {
        g_resultOk = 1;
        snprintf(g_resultMsg, sizeof(g_resultMsg), "icon.jpg and icon174.jpg saved!");
    } else if (ok256) {
        g_resultOk = 1;
        snprintf(g_resultMsg, sizeof(g_resultMsg), "icon.jpg saved. icon174.jpg failed.");
    } else {
        g_resultOk = 0;
        snprintf(g_resultMsg, sizeof(g_resultMsg), "Failed! Is the source a valid image?");
    }
}

// File browser
static int isImage(const char* name) {
    int len = strlen(name);
    if (len < 4) return 0;
    const char* ext = name + len - 4;
    if (strcasecmp(ext, ".jpg") == 0) return 1;
    if (strcasecmp(ext, ".png") == 0) return 1;
    if (strcasecmp(ext, ".bmp") == 0) return 1;
    if (strcasecmp(ext, ".tga") == 0) return 1;
    if (len >= 5 && strcasecmp(name + len - 5, ".jpeg") == 0) return 1;
    return 0;
}

static void loadDir(const char* path) {
    g_fileCount = 0;
    if (strcmp(path, "sdmc:/") != 0) {
        strncpy(g_files[0].name,     "..", sizeof(g_files[0].name) - 1);
        strncpy(g_files[0].fullPath, "..", sizeof(g_files[0].fullPath) - 1);
        g_files[0].isDir = 1;
        g_fileCount = 1;
    }
    DIR* dir = opendir(path);
    if (!dir) return;
    FileEntry dirs[MAX_FILES], files[MAX_FILES];
    int dc = 0, fc = 0;
    struct dirent* ent;
    while ((ent = readdir(dir)) != NULL) {
        if (ent->d_name[0] == '.') continue;
        char fp[MAX_PATH];
        int plen = strlen(path);
        snprintf(fp, sizeof(fp), "%s%s%s", path, (plen > 0 && path[plen-1] == '/') ? "" : "/", ent->d_name);
        if (ent->d_type == DT_DIR && dc < MAX_FILES) {
            utf8_strncpy(dirs[dc].name, ent->d_name, sizeof(dirs[0].name));
            strncpy(dirs[dc].fullPath, fp, sizeof(dirs[0].fullPath) - 1);
            dirs[dc].isDir = 1; dc++;
        } else if (isImage(ent->d_name) && fc < MAX_FILES) {
            utf8_strncpy(files[fc].name, ent->d_name, sizeof(files[0].name));
            strncpy(files[fc].fullPath, fp, sizeof(files[0].fullPath) - 1);
            files[fc].isDir = 0; fc++;
        }
    }
    closedir(dir);
    for (int i = 0; i < dc && g_fileCount < MAX_FILES; i++) g_files[g_fileCount++] = dirs[i];
    for (int i = 0; i < fc && g_fileCount < MAX_FILES; i++) g_files[g_fileCount++] = files[i];
}

static void goUpDir() {
    int len = strlen(g_currentDir);
    if (len > 1 && g_currentDir[len-1] == '/') len--;
    int pos = len - 1;
    while (pos > 0 && g_currentDir[pos] != '/') pos--;
    if (pos <= 6) strncpy(g_currentDir, "sdmc:/", sizeof(g_currentDir));
    else g_currentDir[pos+1] = '\0';
}

// Remove icons
static void removeIcons(u64 titleId) {
    char dst256[MAX_PATH], dst174[MAX_PATH];
    snprintf(dst256, sizeof(dst256), "sdmc:/atmosphere/contents/%016lx/icon.jpg",    titleId);
    snprintf(dst174, sizeof(dst174), "sdmc:/atmosphere/contents/%016lx/icon174.jpg", titleId);
    int r1 = remove(dst256);
    int r2 = remove(dst174);
    if (r1 == 0 || r2 == 0) {
        g_resultOk = 1;
        snprintf(g_resultMsg, sizeof(g_resultMsg), "Icons removed successfully.");
    } else {
        g_resultOk = 0;
        snprintf(g_resultMsg, sizeof(g_resultMsg), "No icons found to remove.");
    }
}

// Reboot to payload
static void rebootToPayload() {
    spsmShutdown(true);
}

// FTP Server implementation

// Convert FTP path to sdmc: absolute path
// FTP root "/" maps to "sdmc:/" so user sees the full SD card
static void ftpToSdmcPath(const char* ftpPath, char* out, size_t outSize) {
    const char* rel = ftpPath;
    while (*rel == '/') rel++;
    if (*rel == '\0') {
        snprintf(out, outSize, "sdmc:/");
    } else {
        snprintf(out, outSize, "sdmc:/%.*s", (int)(outSize - 8), rel);
    }
}

// Combine client cwd + arg into absolute FTP path
static void ftpResolvePath(FtpClient* c, const char* arg, char* out, size_t outSize) {
    if (!arg || arg[0] == '\0') {
        snprintf(out, outSize, "/%s", c->cwd);
        return;
    }
    if (arg[0] == '/') {
        snprintf(out, outSize, "%s", arg);
    } else {
        if (c->cwd[0])
            snprintf(out, outSize, "/%s/%s", c->cwd, arg);
        else
            snprintf(out, outSize, "/%s", arg);
    }
}

static void ftpSend(int fd, const char* msg) {
    if (fd < 0) return;
    send(fd, msg, strlen(msg), 0);
}

static void ftpCloseClient(FtpClient* c) {
    if (c->dataFd >= 0)          { close(c->dataFd);          c->dataFd = -1; }
    if (c->passiveListenFd >= 0) { close(c->passiveListenFd); c->passiveListenFd = -1; }
    if (c->ctrlFd >= 0)          { close(c->ctrlFd);          c->ctrlFd = -1; }
    c->recvLen  = 0;
    c->loggedIn = false;
}

static int ftpOpenDataConn(FtpClient* c) {
    if (c->dataFd >= 0) return c->dataFd;
    if (c->passiveListenFd >= 0) {
        // Use select() to wait up to 5 seconds for the client to connect
        fd_set fds;
        FD_ZERO(&fds);
        FD_SET(c->passiveListenFd, &fds);
        struct timeval tv;
        tv.tv_sec  = 5;
        tv.tv_usec = 0;
        int ready = select(c->passiveListenFd + 1, &fds, NULL, NULL, &tv);
        struct sockaddr_in addr;
        socklen_t addrLen = sizeof(addr);
        int fd = -1;
        if (ready > 0) {
            fd = accept(c->passiveListenFd, (struct sockaddr*)&addr, &addrLen);
        }
        close(c->passiveListenFd);
        c->passiveListenFd = -1;
        c->dataFd = fd;
        return fd;
    }
    return -1;
}

static bool ftpHandleCmd(FtpClient* c, char* line) {
    char cmd[16] = {0};
    char arg[MAX_PATH] = {0};

    // Strip trailing CR/LF
    int llen = strlen(line);
    while (llen > 0 && (line[llen-1] == '\r' || line[llen-1] == '\n')) line[--llen] = '\0';

    char* sp = strchr(line, ' ');
    if (sp) {
        int clen = (int)(sp - line);
        if (clen >= (int)sizeof(cmd)) clen = (int)sizeof(cmd) - 1;
        memcpy(cmd, line, clen);
        const char* a = sp + 1;
        while (*a == ' ') a++;
        utf8_strncpy(arg, a, sizeof(arg));
    } else {
        if (llen >= (int)sizeof(cmd)) llen = (int)sizeof(cmd) - 1;
        memcpy(cmd, line, llen);
    }

    // To uppercase
    for (int i = 0; cmd[i]; i++)
        if (cmd[i] >= 'a' && cmd[i] <= 'z') cmd[i] -= 32;

    if (strcmp(cmd, "USER") == 0) { ftpSend(c->ctrlFd, "331 Password required.\r\n"); return true; }
    if (strcmp(cmd, "PASS") == 0) { c->loggedIn = true; ftpSend(c->ctrlFd, "230 Logged in.\r\n"); return true; }
    if (strcmp(cmd, "QUIT") == 0) { ftpSend(c->ctrlFd, "221 Goodbye.\r\n"); return false; }
    if (strcmp(cmd, "SYST") == 0) { ftpSend(c->ctrlFd, "215 UNIX Type: L8\r\n"); return true; }
    if (strcmp(cmd, "FEAT") == 0) { ftpSend(c->ctrlFd, "211-Features:\r\n UTF8\r\n211 End\r\n"); return true; }
    if (strcmp(cmd, "OPTS") == 0) { ftpSend(c->ctrlFd, "200 OK.\r\n"); return true; }
    if (strcmp(cmd, "TYPE") == 0) { c->binaryMode = (arg[0]=='I'||arg[0]=='i'); ftpSend(c->ctrlFd, "200 Type set.\r\n"); return true; }
    if (strcmp(cmd, "MODE") == 0 || strcmp(cmd, "STRU") == 0) { ftpSend(c->ctrlFd, "200 OK.\r\n"); return true; }
    if (strcmp(cmd, "NOOP") == 0) { ftpSend(c->ctrlFd, "200 NOOP OK.\r\n"); return true; }

    if (!c->loggedIn) { ftpSend(c->ctrlFd, "530 Not logged in.\r\n"); return true; }

    // PWD
    if (strcmp(cmd, "PWD") == 0) {
        char resp[MAX_PATH + 16];
        snprintf(resp, sizeof(resp), "257 \"/%s\" is current directory.\r\n", c->cwd);
        ftpSend(c->ctrlFd, resp);
        return true;
    }
    // CWD
    if (strcmp(cmd, "CWD") == 0) {
        char ftpAbs[MAX_PATH], sdmcPath[MAX_PATH];
        ftpResolvePath(c, arg, ftpAbs, sizeof(ftpAbs));
        ftpToSdmcPath(ftpAbs, sdmcPath, sizeof(sdmcPath));
        struct stat st;
        if (strcmp(ftpAbs, "/") == 0 || (stat(sdmcPath, &st) == 0 && S_ISDIR(st.st_mode))) {
            const char* rel = ftpAbs; while (*rel == '/') rel++;
            strncpy(c->cwd, rel, sizeof(c->cwd) - 1);
            c->cwd[sizeof(c->cwd) - 1] = '\0';
            ftpSend(c->ctrlFd, "250 Directory changed.\r\n");
        } else ftpSend(c->ctrlFd, "550 Directory not found.\r\n");
        return true;
    }
    // CDUP
    if (strcmp(cmd, "CDUP") == 0) {
        int len = strlen(c->cwd);
        while (len > 0 && c->cwd[len-1] != '/') len--;
        if (len > 0) len--;
        c->cwd[len] = '\0';
        ftpSend(c->ctrlFd, "250 Directory changed.\r\n");
        return true;
    }
    // PASV
    if (strcmp(cmd, "PASV") == 0) {
        if (c->passiveListenFd >= 0) { close(c->passiveListenFd); c->passiveListenFd = -1; }
        int listenFd = socket(AF_INET, SOCK_STREAM, 0);
        if (listenFd < 0) { ftpSend(c->ctrlFd, "425 Cannot create data socket.\r\n"); return true; }
        int opt = 1;
        setsockopt(listenFd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
        struct sockaddr_in addr;
        memset(&addr, 0, sizeof(addr));
        addr.sin_family = AF_INET; addr.sin_addr.s_addr = inet_addr(g_ftpIpStr); addr.sin_port = 0;
        if (bind(listenFd, (struct sockaddr*)&addr, sizeof(addr)) < 0 || listen(listenFd, 1) < 0) {
            close(listenFd); ftpSend(c->ctrlFd, "425 Cannot bind data socket.\r\n"); return true;
        }
        socklen_t addrLen = sizeof(addr);
        getsockname(listenFd, (struct sockaddr*)&addr, &addrLen);
        fcntl(listenFd, F_SETFL, O_NONBLOCK);
        c->passiveListenFd = listenFd;
        unsigned long ip = inet_addr(g_ftpIpStr);
        unsigned char* ip4 = (unsigned char*)&ip;
        unsigned short port = ntohs(addr.sin_port);
        char resp[64];
        snprintf(resp, sizeof(resp), "227 Entering Passive Mode (%u,%u,%u,%u,%u,%u).\r\n",
            ip4[0], ip4[1], ip4[2], ip4[3], (port>>8)&0xFF, port&0xFF);
        ftpSend(c->ctrlFd, resp);
        return true;
    }
    // LIST
    if (strcmp(cmd, "LIST") == 0 || strcmp(cmd, "NLST") == 0) {
        ftpSend(c->ctrlFd, "150 Opening data connection.\r\n");
        int dataFd = ftpOpenDataConn(c);
        if (dataFd < 0) { ftpSend(c->ctrlFd, "425 No data connection.\r\n"); return true; }
        char sdmcPath[MAX_PATH];
        ftpToSdmcPath(c->cwd[0] ? c->cwd : "", sdmcPath, sizeof(sdmcPath));
        DIR* dir = opendir(sdmcPath);
        if (dir) {
            struct dirent* ent;
            while ((ent = readdir(dir)) != NULL) {
                char fp[MAX_PATH + 256];
                snprintf(fp, sizeof(fp), "%s/%s", sdmcPath, ent->d_name);
                struct stat st; stat(fp, &st);
                char line[512];
                if (strcmp(cmd, "NLST") == 0)
                    snprintf(line, sizeof(line), "%s\r\n", ent->d_name);
                else
                    snprintf(line, sizeof(line), "%srwxr-xr-x 1 ftp ftp %8ld Jan  1 00:00 %s\r\n",
                        S_ISDIR(st.st_mode) ? "d" : "-", (long)st.st_size, ent->d_name);
                send(dataFd, line, strlen(line), 0);
            }
            closedir(dir);
        }
        close(dataFd); c->dataFd = -1;
        ftpSend(c->ctrlFd, "226 Transfer complete.\r\n");
        return true;
    }
    // STOR - upload
    if (strcmp(cmd, "STOR") == 0) {
        char ftpAbs[MAX_PATH], sdmcPath[MAX_PATH];
        ftpResolvePath(c, arg, ftpAbs, sizeof(ftpAbs));
        ftpToSdmcPath(ftpAbs, sdmcPath, sizeof(sdmcPath));
        // Ensure dir exists
        char dirPart[MAX_PATH];
        strncpy(dirPart, sdmcPath, sizeof(dirPart)-1);
        char* slash = strrchr(dirPart, '/');
        if (slash) { *slash = '\0'; mkdir(dirPart, 0777); }
        ftpSend(c->ctrlFd, "150 Opening data connection for upload.\r\n");
        int dataFd = ftpOpenDataConn(c);
        if (dataFd < 0) { ftpSend(c->ctrlFd, "425 No data connection.\r\n"); return true; }
        FILE* f = fopen(sdmcPath, "wb");
        if (!f) { close(dataFd); c->dataFd = -1; ftpSend(c->ctrlFd, "550 Cannot create file.\r\n"); return true; }
        char buf[FTP_BUF_SIZE]; int n;
        while ((n = recv(dataFd, buf, sizeof(buf), 0)) > 0) fwrite(buf, 1, n, f);
        fclose(f); close(dataFd); c->dataFd = -1;
        if (isImage(sdmcPath)) g_ftpFilesReceived++;
        ftpSend(c->ctrlFd, "226 Transfer complete.\r\n");
        snprintf(g_ftpStatus, sizeof(g_ftpStatus), "Uploaded: %.50s", arg[0] ? arg : "file");
        return true;
    }
    // RETR - download not supported
    if (strcmp(cmd, "RETR") == 0) {
        ftpSend(c->ctrlFd, "550 Download not supported.\r\n");
        return true;
    }
    // DELE
    if (strcmp(cmd, "DELE") == 0) {
        char ftpAbs[MAX_PATH], sdmcPath[MAX_PATH];
        ftpResolvePath(c, arg, ftpAbs, sizeof(ftpAbs)); ftpToSdmcPath(ftpAbs, sdmcPath, sizeof(sdmcPath));
        if (remove(sdmcPath) == 0) ftpSend(c->ctrlFd, "250 File deleted.\r\n");
        else ftpSend(c->ctrlFd, "550 Delete failed.\r\n");
        return true;
    }
    // MKD
    if (strcmp(cmd, "MKD") == 0) {
        char ftpAbs[MAX_PATH], sdmcPath[MAX_PATH];
        ftpResolvePath(c, arg, ftpAbs, sizeof(ftpAbs)); ftpToSdmcPath(ftpAbs, sdmcPath, sizeof(sdmcPath));
        if (mkdir(sdmcPath, 0777) == 0) {
            char resp[MAX_PATH+8]; snprintf(resp, sizeof(resp), "257 \"%s\" created.\r\n", ftpAbs);
            ftpSend(c->ctrlFd, resp);
        } else ftpSend(c->ctrlFd, "550 MKD failed.\r\n");
        return true;
    }
    // RMD
    if (strcmp(cmd, "RMD") == 0) {
        char ftpAbs[MAX_PATH], sdmcPath[MAX_PATH];
        ftpResolvePath(c, arg, ftpAbs, sizeof(ftpAbs)); ftpToSdmcPath(ftpAbs, sdmcPath, sizeof(sdmcPath));
        if (rmdir(sdmcPath) == 0) ftpSend(c->ctrlFd, "250 Directory removed.\r\n");
        else ftpSend(c->ctrlFd, "550 RMD failed.\r\n");
        return true;
    }
    // RNFR / RNTO
    if (strcmp(cmd, "RNFR") == 0) {
        char ftpAbs[MAX_PATH];
        ftpResolvePath(c, arg, ftpAbs, sizeof(ftpAbs));
        ftpToSdmcPath(ftpAbs, c->renamePending, sizeof(c->renamePending));
        ftpSend(c->ctrlFd, "350 Ready for RNTO.\r\n"); return true;
    }
    if (strcmp(cmd, "RNTO") == 0) {
        char ftpAbs[MAX_PATH], sdmcPath[MAX_PATH];
        ftpResolvePath(c, arg, ftpAbs, sizeof(ftpAbs)); ftpToSdmcPath(ftpAbs, sdmcPath, sizeof(sdmcPath));
        if (rename(c->renamePending, sdmcPath) == 0) ftpSend(c->ctrlFd, "250 Rename OK.\r\n");
        else ftpSend(c->ctrlFd, "550 Rename failed.\r\n");
        c->renamePending[0] = '\0'; return true;
    }
    // SIZE
    if (strcmp(cmd, "SIZE") == 0) {
        char ftpAbs[MAX_PATH], sdmcPath[MAX_PATH];
        ftpResolvePath(c, arg, ftpAbs, sizeof(ftpAbs)); ftpToSdmcPath(ftpAbs, sdmcPath, sizeof(sdmcPath));
        struct stat st;
        if (stat(sdmcPath, &st) == 0) {
            char resp[32]; snprintf(resp, sizeof(resp), "213 %ld\r\n", (long)st.st_size);
            ftpSend(c->ctrlFd, resp);
        } else ftpSend(c->ctrlFd, "550 File not found.\r\n");
        return true;
    }

    ftpSend(c->ctrlFd, "502 Command not implemented.\r\n");
    return true;
}

static void ftpPoll() {
    if (!g_ftpEnabled) return;
    // Accept new client
    if (g_ftpListenFd >= 0) {
        struct sockaddr_in addr; socklen_t addrLen = sizeof(addr);
        int newFd = accept(g_ftpListenFd, (struct sockaddr*)&addr, &addrLen);
        if (newFd >= 0) {
            for (int i = 0; i < FTP_MAX_CLIENTS; i++) {
                if (g_ftpClients[i].ctrlFd < 0) {
                    FtpClient* c = &g_ftpClients[i];
                    c->ctrlFd = newFd; c->dataFd = -1; c->passiveListenFd = -1;
                    c->recvLen = 0; c->loggedIn = false; c->binaryMode = true;
                    c->cwd[0] = '\0'; c->renamePending[0] = '\0';
                    fcntl(newFd, F_SETFL, O_NONBLOCK);
                    ftpSend(newFd, "220 IconSwap FTP Server Ready (UTF-8).\r\n");
                    snprintf(g_ftpStatus, sizeof(g_ftpStatus), "Client connected: %s", inet_ntoa(addr.sin_addr));
                    goto acceptDone;
                }
            }
            close(newFd); // no free slot
            acceptDone:;
        }
    }
    // Service clients
    for (int i = 0; i < FTP_MAX_CLIENTS; i++) {
        FtpClient* c = &g_ftpClients[i];
        if (c->ctrlFd < 0) continue;
        char tmp[FTP_BUF_SIZE];
        int n = recv(c->ctrlFd, tmp, sizeof(tmp), 0);
        if (n == 0) { ftpCloseClient(c); continue; }
        if (n < 0)  { if (errno != EAGAIN && errno != EWOULDBLOCK) ftpCloseClient(c); continue; }
        int space = FTP_BUF_SIZE - c->recvLen - 1;
        if (n > space) n = space;
        memcpy(c->recvBuf + c->recvLen, tmp, n);
        c->recvLen += n; c->recvBuf[c->recvLen] = '\0';
        char* lineStart = c->recvBuf;
        char* nl;
        while ((nl = strchr(lineStart, '\n')) != NULL) {
            *nl = '\0';
            bool keep = ftpHandleCmd(c, lineStart);
            if (!keep) { ftpCloseClient(c); goto nextClient; }
            lineStart = nl + 1;
        }
        {
            int remaining = (int)(c->recvBuf + c->recvLen - lineStart);
            if (remaining > 0 && lineStart != c->recvBuf) memmove(c->recvBuf, lineStart, remaining);
            c->recvLen = remaining; c->recvBuf[c->recvLen] = '\0';
        }
        nextClient:;
    }
}

// Get local IP by briefly connecting a UDP socket - no packets sent,
// just lets the OS pick the right network interface.
static bool getLocalIp(char* out, size_t outSize) {
    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) return false;
    struct sockaddr_in remote;
    memset(&remote, 0, sizeof(remote));
    remote.sin_family      = AF_INET;
    remote.sin_port        = htons(80);
    remote.sin_addr.s_addr = inet_addr("8.8.8.8");
    fcntl(fd, F_SETFL, O_NONBLOCK);
    connect(fd, (struct sockaddr*)&remote, sizeof(remote));
    struct sockaddr_in local;
    socklen_t localLen = sizeof(local);
    bool ok = (getsockname(fd, (struct sockaddr*)&local, &localLen) == 0 &&
               local.sin_addr.s_addr != 0);
    if (ok) snprintf(out, outSize, "%s", inet_ntoa(local.sin_addr));
    close(fd);
    return ok;
}

static bool ftpStart() {
    // Primary: UDP socket trick (reliable, no nifm dependency)
    if (!getLocalIp(g_ftpIpStr, sizeof(g_ftpIpStr))) {
        // Fallback: nifm
        nifmInitialize(NifmServiceType_User);
        u32 ipAddr = 0;
        nifmGetCurrentIpAddress(&ipAddr);
        nifmExit();
        if (ipAddr == 0) {
            snprintf(g_ftpStatus, sizeof(g_ftpStatus), "No network (IP=0). Check Wi-Fi.");
            return false;
        }
        struct in_addr ia; ia.s_addr = ipAddr;
        snprintf(g_ftpIpStr, sizeof(g_ftpIpStr), "%s", inet_ntoa(ia));
    }

    g_ftpListenFd = socket(AF_INET, SOCK_STREAM, 0);
    if (g_ftpListenFd < 0) {
        snprintf(g_ftpStatus, sizeof(g_ftpStatus), "socket() failed: %d", errno);
        return false;
    }
    int opt = 1;
    setsockopt(g_ftpListenFd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET; addr.sin_addr.s_addr = INADDR_ANY; addr.sin_port = htons(FTP_PORT);
    if (bind(g_ftpListenFd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        snprintf(g_ftpStatus, sizeof(g_ftpStatus), "bind() failed: %d", errno);
        close(g_ftpListenFd); g_ftpListenFd = -1;
        return false;
    }
    if (listen(g_ftpListenFd, FTP_MAX_CLIENTS) < 0) {
        snprintf(g_ftpStatus, sizeof(g_ftpStatus), "listen() failed: %d", errno);
        close(g_ftpListenFd); g_ftpListenFd = -1;
        return false;
    }
    fcntl(g_ftpListenFd, F_SETFL, O_NONBLOCK);
    for (int i = 0; i < FTP_MAX_CLIENTS; i++) {
        g_ftpClients[i].ctrlFd = -1; g_ftpClients[i].dataFd = -1; g_ftpClients[i].passiveListenFd = -1;
    }
    g_ftpEnabled = 1;
    snprintf(g_ftpStatus, sizeof(g_ftpStatus), "Waiting for connections...");
    return true;
}

static void ftpStop() {
    for (int i = 0; i < FTP_MAX_CLIENTS; i++) ftpCloseClient(&g_ftpClients[i]);
    if (g_ftpListenFd >= 0) { close(g_ftpListenFd); g_ftpListenFd = -1; }
    g_ftpEnabled = 0;
    snprintf(g_ftpStatus, sizeof(g_ftpStatus), "FTP stopped.");
}

// Render functions
static void renderRebootConfirm() {
    consoleClear();
    printf("=== IconSwap - Reboot to Payload ===\n\n");
    printf("Reboot now and load payload?\n\n");
    printf("Make sure reboot_payload.bin is at:\n");
    printf("  atmosphere/reboot_payload.bin\n\n");
    printf("A: Reboot now    B: Cancel\n");
}

static void renderGameList() {
    consoleClear();
    printf("=== IconSwap - Select Game ===  (Total: %d)\n\n", g_recordCount);
    int end = g_gameScroll + WINDOW_SIZE;
    if (end > g_recordCount) end = g_recordCount;
    for (int i = g_gameScroll; i < end; i++) {
        char path[MAX_PATH];
        snprintf(path, sizeof(path), "sdmc:/atmosphere/contents/%016lx/icon.jpg", g_records[i].application_id);
        struct stat st;
        const char* tag = (stat(path, &st) == 0) ? "[*]" : "   ";
        if (i == g_gameSelected)
            printf("> %s [%016lX] %s\n", tag, g_records[i].application_id, g_names[i]);
        else
            printf("  %s  %016lX  %s\n", tag, g_records[i].application_id, g_names[i]);
    }
    printf("\nUp/Down: move 1  Left/Right: move 10  A: assign icon  +: exit\n");
    printf("Y: remove icons  -: reboot to payload  X: FTP menu\n");
    if (g_ftpEnabled) printf("[FTP ON: %s port 21]\n", g_ftpIpStr);
}

static void renderFileBrowser() {
    consoleClear();
    printf("=== IconSwap - Select Image ===\n");
    printf("Game: %.60s\n", g_names[g_gameSelected]);
    printf("Dir : %.70s\n\n", g_currentDir);
    int end = g_fileScroll + WINDOW_SIZE;
    if (end > g_fileCount) end = g_fileCount;
    if (g_fileCount == 0) printf("  (no image files or folders here)\n");
    for (int i = g_fileScroll; i < end; i++) {
        const char* slash = g_files[i].isDir ? "/" : "";
        if (i == g_fileSelected)
            printf("> %.70s%s\n", g_files[i].name, slash);
        else
            printf("  %.70s%s\n", g_files[i].name, slash);
    }
    printf("\nUp/Down: move  A: open folder / select image  B: back\n");
    printf("Supported: JPG PNG BMP TGA  (UTF-8 filenames supported)\n");
}

static void renderConfirm() {
    consoleClear();
    printf("=== IconSwap - Confirm ===\n\n");
    printf("Game  : %.60s\n",   g_names[g_gameSelected]);
    printf("TID   : %016lX\n\n", g_records[g_gameSelected].application_id);
    printf("Image : %.70s\n\n", g_selectedImg);
    printf("Will create:\n");
    printf("  icon.jpg    (256x256)\n");
    printf("  icon174.jpg (174x174)\n\n");
    printf("A: Confirm and apply    B: Cancel\n");
}

static void renderResult() {
    consoleClear();
    printf("=== IconSwap - Done ===\n\n");
    if (g_resultOk)
        printf("OK: %s\n\nReboot Switch to see icon on HOME menu.\n", g_resultMsg);
    else
        printf("ERROR: %s\n", g_resultMsg);
    printf("\nA: Back to game list    -: Reboot to payload    +: Exit\n");
}

static void renderFtp() {
    consoleClear();
    printf("=== IconSwap - FTP Server ===\n\n");
    if (!g_ftpEnabled) {
        printf("ERROR: Could not start FTP server.\n");
        printf("Make sure Wi-Fi is connected.\n\n");
        printf("Status: %s\n", g_ftpStatus);
    } else {
        printf("FTP server: RUNNING\n\n");
        printf("  IP Address : %s\n", g_ftpIpStr);
        printf("  Port       : %d\n", FTP_PORT);
        printf("  Login      : any username / any password\n");
        printf("  Encoding   : UTF-8\n\n");
        printf("  Status     : %s\n", g_ftpStatus);
        printf("  Uploaded   : %d image(s) this session\n", g_ftpFilesReceived);
    }
    printf("\nB: Back to game list\n");
}

// Main
int main(int argc, char** argv) {
    consoleInit(NULL);
    nsInitialize();
    fsInitialize();
    spsmInitialize();
    socketInitializeDefault();

    padConfigureInput(1, HidNpadStyleSet_NpadStandard);
    PadState pad;
    padInitializeDefault(&pad);

    Result rc = nsListApplicationRecord(g_records, MAX_TITLES, 0, &g_recordCount);
    if (R_FAILED(rc)) {
        printf("Error listing applications: 0x%x\n", rc);
        consoleUpdate(NULL);
        svcSleepThread(3000000000ULL);
        goto cleanup;
    }

    for (s32 i = 0; i < g_recordCount; i++) {
        NsApplicationControlData ctrl;
        size_t ctrlSize;
        rc = nsGetApplicationControlData(NsApplicationControlSource_Storage,
             g_records[i].application_id, &ctrl, sizeof(ctrl), &ctrlSize);
        if (R_SUCCEEDED(rc)) {
            NacpLanguageEntry* lang = NULL;
            if (R_SUCCEEDED(nacpGetLanguageEntry(&ctrl.nacp, &lang)) && lang != NULL)
                utf8_strncpy(g_names[i], lang->name, sizeof(g_names[i]));
            else
                utf8_strncpy(g_names[i], ctrl.nacp.lang[0].name, sizeof(g_names[i]));
        } else {
            snprintf(g_names[i], sizeof(g_names[i]), "%016lX", g_records[i].application_id);
        }
    }

    loadDir(g_currentDir);

    while (appletMainLoop()) {
        padUpdate(&pad);
        u64 kDown = padGetButtonsDown(&pad);
        if (kDown & HidNpadButton_Plus) break;

        ftpPoll();

        switch (g_screen) {
            case SCREEN_GAMELIST:
                if (kDown & HidNpadButton_Down) {
                    if (g_gameSelected < g_recordCount - 1) {
                        g_gameSelected++;
                        if (g_gameSelected >= g_gameScroll + WINDOW_SIZE) g_gameScroll++;
                        if (g_gameScroll > g_recordCount - WINDOW_SIZE) g_gameScroll = g_recordCount - WINDOW_SIZE;
                        if (g_gameScroll < 0) g_gameScroll = 0;
                    }
                }
                if (kDown & HidNpadButton_Up) {
                    if (g_gameSelected > 0) {
                        g_gameSelected--;
                        if (g_gameSelected < g_gameScroll) g_gameScroll--;
                        if (g_gameScroll < 0) g_gameScroll = 0;
                    }
                }
                if (kDown & HidNpadButton_Right) {
                    g_gameSelected += 10;
                    if (g_gameSelected >= g_recordCount) g_gameSelected = g_recordCount - 1;
                    if (g_gameSelected >= g_gameScroll + WINDOW_SIZE) {
                        g_gameScroll = g_gameSelected - WINDOW_SIZE + 1;
                        if (g_gameScroll < 0) g_gameScroll = 0;
                    }
                }
                if (kDown & HidNpadButton_Left) {
                    g_gameSelected -= 10;
                    if (g_gameSelected < 0) g_gameSelected = 0;
                    if (g_gameSelected < g_gameScroll) {
                        g_gameScroll = g_gameSelected;
                        if (g_gameScroll < 0) g_gameScroll = 0;
                    }
                }
                if (kDown & HidNpadButton_A) {
                    if (g_recordCount > 0) {
                        strncpy(g_currentDir, "sdmc:/", sizeof(g_currentDir));
                        g_fileSelected = 0; g_fileScroll = 0;
                        loadDir(g_currentDir);
                        g_screen = SCREEN_FILEBROWSER;
                    }
                }
                if (kDown & HidNpadButton_Y) {
                    if (g_recordCount > 0) {
                        removeIcons(g_records[g_gameSelected].application_id);
                        g_screen = SCREEN_RESULT;
                    }
                }
                if (kDown & HidNpadButton_Minus) {
                    g_screen = SCREEN_REBOOT_CONFIRM;
                }
                if (kDown & HidNpadButton_X) {
                    if (!g_ftpEnabled) ftpStart();
                    g_screen = SCREEN_FTP;
                }
                renderGameList();
                break;

            case SCREEN_FILEBROWSER:
                if (kDown & HidNpadButton_Down) {
                    if (g_fileSelected < g_fileCount - 1) {
                        g_fileSelected++;
                        if (g_fileSelected >= g_fileScroll + WINDOW_SIZE) g_fileScroll++;
                    }
                }
                if (kDown & HidNpadButton_Up) {
                    if (g_fileSelected > 0) {
                        g_fileSelected--;
                        if (g_fileSelected < g_fileScroll) g_fileScroll--;
                    }
                }
                if (kDown & HidNpadButton_A) {
                    if (g_fileCount > 0) {
                        FileEntry* f = &g_files[g_fileSelected];
                        if (f->isDir) {
                            if (strcmp(f->name, "..") == 0) {
                                goUpDir();
                            } else {
                                strncpy(g_currentDir, f->fullPath, sizeof(g_currentDir) - 1);
                                int len = strlen(g_currentDir);
                                if (len > 0 && g_currentDir[len-1] != '/')
                                    strncat(g_currentDir, "/", sizeof(g_currentDir) - len - 1);
                            }
                            g_fileSelected = 0; g_fileScroll = 0;
                            loadDir(g_currentDir);
                        } else {
                            strncpy(g_selectedImg, f->fullPath, sizeof(g_selectedImg) - 1);
                            g_screen = SCREEN_CONFIRM;
                        }
                    }
                }
                if (kDown & HidNpadButton_B) {
                    g_screen = SCREEN_GAMELIST;
                }
                renderFileBrowser();
                break;

            case SCREEN_CONFIRM:
                if (kDown & HidNpadButton_A) {
                    applyIcon(g_selectedImg, g_records[g_gameSelected].application_id);
                    g_screen = SCREEN_RESULT;
                }
                if (kDown & HidNpadButton_B) {
                    g_screen = SCREEN_FILEBROWSER;
                }
                renderConfirm();
                break;

            case SCREEN_RESULT:
                if (kDown & HidNpadButton_A) {
                    g_screen = SCREEN_GAMELIST;
                }
                if (kDown & HidNpadButton_Minus) {
                    g_screen = SCREEN_REBOOT_CONFIRM;
                }
                renderResult();
                break;

            case SCREEN_REBOOT_CONFIRM:
                if (kDown & HidNpadButton_A) {
                    rebootToPayload();
                }
                if (kDown & HidNpadButton_B) {
                    g_screen = SCREEN_GAMELIST;
                }
                renderRebootConfirm();
                break;

            case SCREEN_FTP:
                if (kDown & HidNpadButton_B) {
                    g_screen = SCREEN_GAMELIST;
                }
                renderFtp();
                break;
        }

        consoleUpdate(NULL);
    }

cleanup:
    if (g_ftpEnabled) ftpStop();
    socketExit();
    spsmExit();
    fsExit();
    nsExit();
    consoleExit(NULL);
    return 0;
}
